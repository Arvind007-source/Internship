import machine
import math
from ssd1306 import SSD1306_I2C
import time

# Initialize I2C for OLED
i2c = machine.SoftI2C(scl=machine.Pin(22), sda=machine.Pin(21))
oled = SSD1306_I2C(128, 64, i2c)

# DFT function
def dft(input_signal):
    N = len(input_signal)
    output_signal = [0] * N
    for k in range(N):
        real_sum = 0
        imag_sum = 0
        for n in range(N):
            angle = 2 * math.pi * k * n / N
            real_sum += input_signal[n] * math.cos(angle)
            imag_sum -= input_signal[n] * math.sin(angle)
        output_signal[k] = complex(real_sum, imag_sum)
    return output_signal

# Sample 1D signal
input_signal = [1, 2, 3, 4, 5, 6, 7, 8]

# Compute DFT
dft_result = dft(input_signal)

# Compute magnitude spectrum
magnitude_spectrum = [abs(x) for x in dft_result]

# Function to display values on OLED
def display_values(values, y_offset=0):
    oled.fill(0)
    for i, value in enumerate(values):
        oled.text(str(value), 0, y_offset + i * 10)
    oled.show()

# Function to display spectrum on OLED
def display_spectrum(spectrum, x_offset=64):
    oled.fill(0)
    max_magnitude = max(spectrum)
    for i, magnitude in enumerate(spectrum):
        x = x_offset + i * (64 // len(spectrum))
        y = int((magnitude / max_magnitude) * 64)
        oled.line(x, 64, x, 64 - y, 1)
    oled.show()

# Display the original array values on the left side of the OLED
display_values(input_signal)

# Delay to allow viewing the original array values
time.sleep(5)

# Display the magnitude spectrum on the right side of the OLED
display_spectrum(magnitude_spectrum)

# Optionally, display both values and spectrum together
oled.fill(0)
for i, value in enumerate(input_signal):
    oled.text(str(value), 0, i * 10)

max_magnitude = max(magnitude_spectrum)
for i, magnitude in enumerate(magnitude_spectrum):
    x = 64 + i * (64 // len(magnitude_spectrum))
    y = int((magnitude / max_magnitude) * 64)
    oled.line(x, 64, x, 64 - y, 1)
    
oled.show()