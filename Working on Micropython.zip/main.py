from machine import Pin
from time import sleep,sleep_ms

# Set up the LED pin and BUZZER pin
led=Pin(2,Pin.OUT)
buzzer=Pin(25,Pin.OUT)

def beep(duration_ms):
    for _ in range(duration_ms):
        buzzer.on()
        sleep_ms(1)
        buzzer.off()
        sleep_ms(1)


while True:
    led.on() # Turn the LED on
    print("LED IS ON !!!") # Print Message 
    beep(1000)
    led.off() # Turn the LED off
    print("LED IS OFF !!!") # Print Message 
    sleep(1) # Wait for 1 second
