import machine
import time
from ssd1306 import SSD1306_I2C

# Initialize I2C for OLED
i2c = machine.SoftI2C(scl=machine.Pin(22), sda=machine.Pin(21))
oled = SSD1306_I2C(128, 64, i2c)

# Sample 8x8 image (a simple pattern)
image = [
    [0, 255, 0, 255, 0, 255, 0, 255],
    [255, 0, 255, 0, 255, 0, 255, 0],
    [0, 255, 0, 255, 0, 255, 0, 255],
    [255, 0, 255, 0, 255, 0, 255, 0],
    [0, 255, 0, 255, 0, 255, 0, 255],
    [255, 0, 255, 0, 255, 0, 255, 0],
    [0, 255, 0, 255, 0, 255, 0, 255],
    [255, 0, 255, 0, 255, 0, 255, 0]
]

# Function to display an 8x8 image on the OLED
def display_image(img):
    oled.fill(0)
    for y in range(8):
        for x in range(8):
            color = img[y][x]
            if color > 0:
                oled.pixel(x + 10, y + 10, 1)  # Offset for visibility
    oled.show()

# Display the original image
display_image(image)
time.sleep(5)

def box_blur(image):
    height = len(image)
    width = len(image[0])
    blurred_image = [[0 for _ in range(width)] for _ in range(height)]
    
    for i in range(1, height-1):
        for j in range(1, width-1):
            total = (
                image[i-1][j-1] + image[i-1][j] + image[i-1][j+1] +
                image[i][j-1] + image[i][j] + image[i][j+1] +
                image[i+1][j-1] + image[i+1][j] + image[i+1][j+1]
            )
            blurred_image[i][j] = total // 9
    
    return blurred_image

# Apply the 3x3 box blur to the image
smoothed_image = box_blur(image)

# Display the smoothed image
display_image(smoothed_image)
time.sleep(5)
